﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using WPFAPP.Models;

namespace WPFAPP.ViewModels
{
    public class ClientViewModel : INotifyPropertyChanged
    {
        // Declaring the PropertyChanged event
        public event PropertyChangedEventHandler PropertyChanged;

        //OnPropertyChanged method to raise the event
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        // Properties -------------
        
        private ClientDetail _clientDetail;

        public ClientDetail ClientDetail
        {
            get 
            { 
                return _clientDetail;
            }
            set 
            { 
            _clientDetail = value; 
            OnPropertyChanged(nameof(ClientDetail));
            }
        }

        private ObservableCollection<ClientDetail> _lstclientDetail;

        public ObservableCollection<ClientDetail> LstClientDetail
        {
            get
            {
                return _lstclientDetail;
            }
            set
            {
                _lstclientDetail = value;
                OnPropertyChanged(nameof(LstClientDetail));
            }
        }


        private ClientDetail _selectedClient;

        public ClientDetail SelectedClient
        {
            get { return _selectedClient; }

            set { _selectedClient = value;
                OnPropertyChanged(nameof(SelectedClient));
            }
        }

        private ClientDetail clientDetail = new ClientDetail();

        public ClientDetail ClientDetail1
        {
            get { return clientDetail; }

            set
            {
                clientDetail = value;
                OnPropertyChanged(nameof(ClientDetail1));
            }
        }
        // End of Properties-----------



        ClientEntities clientEntities;
        
        // Constructor 
        public ClientViewModel()
        {
            clientEntities = new ClientEntities();
            LoadClient();
            DeleteCommand = new Command((s) => true, Delete);
            UpdateCommand = new Command((s) => true, Update);
            UpdateClientCommand = new Command((s) => true, UpdateClient);
            AddClientCommand = new Command((s) => true, AddClient);
        }

        // Methods -----------------
        private void AddClient(object obj)
        {

            Random rnd = new Random();
            int number = rnd.Next(999999);
            ClientDetail1.ID = number.ToString();
            clientEntities.ClientDetails.Add(ClientDetail1);
            clientEntities.SaveChanges();
            LstClientDetail.Add(ClientDetail1);
            
            ClientDetail1 = new ClientDetail();

        }

        private void UpdateClient(object obj)
        {
            clientEntities.SaveChanges();
            SelectedClient = new ClientDetail();
        }

        private void Update(object obj)
        {
            SelectedClient = obj as ClientDetail;
        }

        private void Delete(object obj)
        {
            var cli = obj as ClientDetail;
            clientEntities.ClientDetails.Remove(cli);
            clientEntities.SaveChanges();
            LstClientDetail.Remove(cli);
        }

        
        private void LoadClient() // Read details
        {
            LstClientDetail = new ObservableCollection<ClientDetail>(clientEntities.ClientDetails);
        }

        // End ofMethods -----------------

        public ICommand DeleteCommand { get ; set ; }
        public ICommand UpdateCommand { get; set; }
        public ICommand UpdateClientCommand { get; set; }
        public ICommand AddClientCommand { get; set; }

        


    }
    // I Command Interface
    class Command : ICommand
    {
        
        public Command(Func<object, bool> methodCanExecute, Action<object> methodExecute)
        {
            MethodCanExecute = methodCanExecute;
            MethodExecute = methodExecute;
        }
        Action<object> MethodExecute;
        Func<object, bool> MethodCanExecute;



        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            return MethodExecute != null && MethodCanExecute.Invoke(parameter);
        }

        public void Execute(object parameter)
        {
            MethodExecute(parameter);
        }
    }
}
